var adress = "http://127.0.0.1";
var port = "8080";

window.onload = function () {
    var oTab = document.getElementById("tab");
    var aH3 = oTab.getElementsByTagName("h3");
    var aDiv = oTab.getElementsByTagName("div");
    for (var i = 0; i < aH3.length; i++) {
        aH3[i].index = i;
        aH3[i].onclick = function () {
            for (var i = 0; i < aH3.length; i++) {
                aH3[i].className = "";
                aDiv[i].style.display = "none";
                aDiv[this.index].className = "";
                aDiv[this.index].className = "content";
            }
            this.className = "active";
            aDiv[this.index].style.display = "block";
        };
    }
};


var transdata;
var sparqldata;
var test = document.getElementById('test');
var bt = document.getElementById('bt');
var bt2 = document.getElementById('bt2');
var bt3 = document.getElementById('bt3');
var brut = document.getElementById('brut');
var tran = document.getElementById('tran');


bt.onclick = function () {
    document.getElementById("viewArea").innerHTML = '';
    document.getElementById("time1").innerHTML = '';
    document.getElementById("time2").innerHTML = '';
    document.getElementById("time3").innerHTML = '';
    document.getElementById("test").innerHTML = '';
    document.getElementById("res1").innerHTML = '';
    document.getElementById("res2").innerHTML = '';
    document.getElementById("res3").innerHTML = '';
    var query = document.getElementById('query1').value;
    var format = document.getElementById('format1').value;
    var lab = document.getElementById('lab1').value;
    var beginYear = document.getElementById('beginYear1').value;
    var endYear = document.getElementById('endYear1').value;
    if (endYear < beginYear) window.alert("Error : The end year can not be larger than the begin year.");
    else {
        var v = {"query": query, "format": format, "lab": lab, "beginYear": beginYear, "endYear": endYear, "type": 1};
        v = JSON.stringify(v);
        //v={"query":query, "format":format, "lab":lab, "beginYear":beginYear, "endYear":endYear}
        //var result = httpquery(v);
        //sparqldata = result[0];
        //transdata = result[1];
        //lauch(transdata);

        var xmlHttp = new XMLHttpRequest();
        xmlHttp.onreadystatechange = function () {
            if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
                sparqldata = JSON.stringify(JSON.parse(xmlHttp.responseText)[0]);
                transdata = JSON.stringify(JSON.parse(xmlHttp.responseText)[1]);
                var times = JSON.parse(xmlHttp.responseText)[2];
                var t1 = new Date();
                if (JSON.parse(sparqldata).results.bindings.length != 0) {
                    launch(transdata, 1, lab, "");
                    var t2 = new Date();
                    var mtime = parseInt(t2 - t1) / 1000;
                    document.getElementById("time1").innerHTML = "--SPARQL query execution time : " + times.query_time + "s"
                    document.getElementById("time2").innerHTML = "--Transformation execution time : " + times.trans_time + "s"
                    document.getElementById("time3").innerHTML = "--Graphic library loading time : " + mtime + "s";
                    document.getElementById("test").innerHTML = "(Result statistics)";
                    document.getElementById("res1").innerHTML = "--Number of SPARQL query results : " + times.res_number;
                    document.getElementById("res2").innerHTML = "--Number of authors (node) : " + times.node_number;
                    document.getElementById("res3").innerHTML = "--Number of copublication relations (edge) : " + times.edge_number;
                } else window.alert("No copublication results found in " + lab + " from " + beginYear + " to " + endYear + ".");
            }
        }
    }
    ;
    xmlHttp.open('POST', adress + ":" + port + "/", false);
    //xmlHttp.open('POST', "/data", false);
    xmlHttp.send(v); //send the encoded query string
};

bt2.onclick = function () {
    document.getElementById("viewArea").innerHTML = '';
    document.getElementById("time1").innerHTML = '';
    document.getElementById("time2").innerHTML = '';
    document.getElementById("time3").innerHTML = '';
    document.getElementById("test").innerHTML = '';
    document.getElementById("res1").innerHTML = '';
    document.getElementById("res2").innerHTML = '';
    document.getElementById("res3").innerHTML = '';
    var query = document.getElementById('query2').value;
    var format = document.getElementById('format2').value;
    var lab1 = document.getElementById('lab2a').value;
    var lab2 = document.getElementById('lab2b').value;
    var beginYear = document.getElementById('beginYear2').value;
    var endYear = document.getElementById('endYear2').value;
    if (lab1 == lab2) window.alert("The two laboratories can not be the same. Please check your selection.");
    else if (endYear < beginYear) window.alert("Error : The end year can not be larger than the begin year.");
    else {
        var v = {
            "query": query,
            "format": format,
            "lab1": lab1,
            "lab2": lab2,
            "beginYear": beginYear,
            "endYear": endYear,
            "type": 2
        };
        v = JSON.stringify(v);
        var xmlHttp = new XMLHttpRequest();
        xmlHttp.onreadystatechange = function () {
            if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
                sparqldata = JSON.stringify(JSON.parse(xmlHttp.responseText)[0]);
                transdata = JSON.stringify(JSON.parse(xmlHttp.responseText)[1]);
                var times = JSON.parse(xmlHttp.responseText)[2];
                var t1 = new Date();
                if (JSON.parse(sparqldata).results.bindings.length != 0) {
                    launch(transdata, 2, lab1, lab2);
                    var t2 = new Date();
                    var mtime = parseInt(t2 - t1) / 1000;
                    document.getElementById("time1").innerHTML = "--SPARQL query execution time : " + times.query_time + "s"
                    document.getElementById("time2").innerHTML = "--Transformation execution time : " + times.trans_time + "s"
                    document.getElementById("time3").innerHTML = "--Graphic library loading time : " + mtime + "s";
                    document.getElementById("test").innerHTML = "(Result statistics)";
                    document.getElementById("res1").innerHTML = "--Number of SPARQL query results : " + times.res_number;
                    document.getElementById("res2").innerHTML = "--Number of authors (node) : " + times.node_number;
                    document.getElementById("res3").innerHTML = "--Number of copublication relations (edge) : " + times.edge_number;
                } else window.alert("No copublication results found between " + lab1 + " and " + lab2 + " from " + beginYear + " to " + endYear + ".");
            }
        };
        xmlHttp.open('POST', adress + ":" + port + "/", false);
        xmlHttp.send(v); //send the encoded query string
    }
};

bt3.onclick = function () {
    document.getElementById("viewArea").innerHTML = '';
    document.getElementById("time1").innerHTML = '';
    document.getElementById("time2").innerHTML = '';
    document.getElementById("time3").innerHTML = '';
    document.getElementById("test").innerHTML = '';
    document.getElementById("res1").innerHTML = '';
    document.getElementById("res2").innerHTML = '';
    document.getElementById("res3").innerHTML = '';
    var query = document.getElementById('query3').value;
    var format = document.getElementById('format3').value;
    var lab = document.getElementById('lab3').value;
    var country = document.getElementById('country').value;
    var beginYear = document.getElementById('beginYear3').value;
    var endYear = document.getElementById('endYear3').value;
    if (endYear < beginYear) window.alert("Error : The end year can not be larger than the begin year.");
    else {
        var v = {
            "query": query,
            "format": format,
            "lab": lab,
            "country": country,
            "beginYear": beginYear,
            "endYear": endYear,
            "type": 3
        };
        v = JSON.stringify(v);
        //v={"query":query, "format":format, "lab":lab, "beginYear":beginYear, "endYear":endYear}
        //var result = httpquery(v);
        //sparqldata = result[0];
        //transdata = result[1];
        //lauch(transdata);

        var xmlHttp = new XMLHttpRequest();
        xmlHttp.onreadystatechange = function () {
            if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
                sparqldata = JSON.stringify(JSON.parse(xmlHttp.responseText)[0]);
                transdata = JSON.stringify(JSON.parse(xmlHttp.responseText)[1]);
                var times = JSON.parse(xmlHttp.responseText)[2];
                var t1 = new Date();
                if (JSON.parse(sparqldata).results.bindings.length != 0) {
                    launch(transdata, 3, lab, country);

                    var t2 = new Date();
                    var mtime = parseInt(t2 - t1) / 1000;
                    document.getElementById("time1").innerHTML = "--SPARQL query execution time : " + times.query_time + "s"
                    document.getElementById("time2").innerHTML = "--Transformation execution time : " + times.trans_time + "s"
                    document.getElementById("time3").innerHTML = "--Graphic library loading time : " + mtime + "s";
                    document.getElementById("test").innerHTML = "(Result statistics)";
                    document.getElementById("res1").innerHTML = "--Number of SPARQL query results : " + times.res_number;
                    document.getElementById("res2").innerHTML = "--Number of authors (node) : " + times.node_number;
                    document.getElementById("res3").innerHTML = "--Number of copublication relations (edge) : " + times.edge_number;
                } else {
                    window.alert("No copublication results found between " + lab + " and " + country + " from " + beginYear + " to " + endYear + ".");
                }
            }
        };
        xmlHttp.open('POST', adress + ":" + port + "/", false);
        //xmlHttp.open('POST', "/data", false);
        xmlHttp.send(v); //send the encoded query string
    }
};

function showSparqlResults() {
    var window2 = window.open();
    window2.document.write("<head><title>SPARQL Results</title></head>");
    window2.document.write("<body><p>" + sparqldata + "</p></body>");
    window2.focus();
};

function showTransResults() {
    var window2 = window.open();
    window2.document.write("<head><title>Transformed Results</title></head>");
    window2.document.write("<body><p>" + transdata + "</p></body>");
    window2.focus();
};
