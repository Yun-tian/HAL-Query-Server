var port_number = 8080
//var documentRoot = '/home/yuntian/Desktop/ui_server_v2';
var documentRoot = '/home/user/WebstormProjects/ui_server_v2';
var http = require('http');
var fs = require('fs');

function getFrenchName(country) {
    if (country == "France") return "France";
    if (country == "United Kingdom") return "Royaume-Uni";
    if (country == "United States") return "États-Unis";
    if (country == "Spain") return "Espagne";
    if (country == "Germany") return "Allemagne";
    if (country == "Italy") return "Italie";
    if (country == "Portugal") return "Portugal";
    if (country == "China") return "Chine";
    if (country == "Japan") return "Japon";
    if (country == "Vietnam") return "Vietnam";
    if (country == "Russia") return "Russie";
    if (country == "Brazil") return "Brésil";
    if (country == "Mexico") return "Mexique";
    if (country == "Morocco") return "Maroc";
    return "unknown";
}

var server = http.createServer(function (req, res) {
    var url = req.url;
    //console.log(url);
    if (url != "/") {
        var file = documentRoot + url;
        fs.readFile(file, function (err, data) {
            if (err) {
                res.writeHeader(404, {
                    'content-type': 'text/html;charset="utf-8"'
                });
                res.write('<h1>404 Forbidden</h1><p>The page does not exist.</p>');
                res.end();
            } else {
                var extName = url.substring(url.lastIndexOf(".")).toLowerCase();
                switch (extName) {
                    case ".js":
                        res.writeHeader(200, {'content-type': 'text/javascript;charset="utf-8"'});
                        break;
                    case ".css":
                        res.writeHeader(200, {'content-type': 'text/css;charset="utf-8"'});
                        break;
                    case ".png":
                        res.writeHeader(200, {'content-type': 'image/png'});
                        break;
                    case ".ico":
                        res.writeHeader(200, {'content-type': 'image/x-icon'});
                        break;
                    default:
                        console.log("Page called.")
                        res.writeHeader(200, {'content-type': 'text/html;charset="utf-8"'});
                }
                res.write(data);
                res.end();
            }
        });
    } else {
        var sttt = '';
        var q = '';
        var f = '';
        var l = '';
        var l1 = '';
        var l2 = '';
        var c = '';
        var by = '';
        var ey = '';
        req.on('data', function (str) {
            sttt = sttt + str;
        });
        req.on('end', function () {
            console.log(sttt);
            var data = JSON.parse(sttt);
            if (data.type == 1) {
                q = data.query;
                f = data.format;
                l = data.lab;
                by = data.beginYear;
                ey = data.endYear;
                q = q.replace(/param/, l);
                q = q.replace(/beginYear/, by);
                q = q.replace(/endYear/, ey);
                res.writeHeader(200, {'Content-Type': 'text/plain', 'Access-Control-Allow-Origin': '*'});
                //var iris = require("./trans_vidas");
                var mg4 = require("./trans_mg4");
                //if (f == "VIDAS") {
                //var result = iris.transform(q);
                //} else {
                var result = mg4.transform(q);
                //}
                result = JSON.stringify(result);
                res.write(result, "utf-8");
                res.end();
            } else if (data.type == 2) {
                q = data.query;
                f = data.format;
                l1 = data.lab1;
                l2 = data.lab2;
                by = data.beginYear;
                ey = data.endYear;
                q = q.replace(/lab1/, l1);
                q = q.replace(/lab2/, l2);
                q = q.replace(/beginYear/, by);
                q = q.replace(/endYear/, ey);
                res.writeHeader(200, {'Content-Type': 'text/plain', 'Access-Control-Allow-Origin': '*'});
                //var iris = require("./trans_vidas");
                var mg4 = require("./trans_mg4");
                //if (f == "VIDAS") {
                //var result = iris.transform(q);
                //} else {
                var result = mg4.transform2(q);
                //}
                result = JSON.stringify(result);
                res.write(result, "utf-8");
                res.end();
            } else {
                q = data.query;
                f = data.format;
                l = data.lab;
                c = data.country;
                by = data.beginYear;
                ey = data.endYear;
                q = q.replace(/lab/, l);
                q = q.replace(/countrye/, c.replace(/ /, "_"));
                q = q.replace(/countryf/, getFrenchName(c));
                q = q.replace(/beginYear/, by);
                q = q.replace(/endYear/, ey);
                res.writeHeader(200, {'Content-Type': 'text/plain', 'Access-Control-Allow-Origin': '*'});
                //var iris = require("./trans_vidas");
                var mg4 = require("./trans_mg4");
                //if (f == "VIDAS") {
                //var result = iris.transform(q);
                //} else {
                var result = mg4.transform2(q);
                //}
                result = JSON.stringify(result);
                res.write(result, "utf-8");
                res.end();
            }
        });
    }
}).listen(port_number);

console.log("Server started at port 8080. Now you can find this page at the website https://134.59.130.139:8080/index.html");
