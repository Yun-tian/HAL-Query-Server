// Default types : 1 Conference Paper, 17 Report, 0 Book, 23 Article
const types = [
    "https://data.archives-ouvertes.fr/doctype/ConferencePaper",
    //"https://data.archives-ouvertes.fr/doctype/Chapter",
    //"https://data.archives-ouvertes.fr/doctype/Douv",
    //"https://data.archives-ouvertes.fr/doctype/Hdr",
    //"https://data.archives-ouvertes.fr/doctype/Image",
    //"https://data.archives-ouvertes.fr/doctype/LectureNotes",
    //"https://data.archives-ouvertes.fr/doctype/Map",
    //"https://data.archives-ouvertes.fr/doctype/Mem",
    //"https://data.archives-ouvertes.fr/doctype/Minutes",
    //"https://data.archives-ouvertes.fr/doctype/Other",
    //"https://data.archives-ouvertes.fr/doctype/Otherreport",
    //"https://data.archives-ouvertes.fr/doctype/Ouv",
    //"https://data.archives-ouvertes.fr/doctype/Patent",
    //"https://data.archives-ouvertes.fr/doctype/ConferencePoster",
    //"https://data.archives-ouvertes.fr/doctype/Presconf",
    //"https://data.archives-ouvertes.fr/doctype/Repact",
    "https://data.archives-ouvertes.fr/doctype/Report",
    //"https://data.archives-ouvertes.fr/doctype/AudioDocument",
    //"https://data.archives-ouvertes.fr/doctype/Synthese",
    //"https://data.archives-ouvertes.fr/doctype/DoctoralThesis",
    //"https://data.archives-ouvertes.fr/doctype/Preprint",
    //"https://data.archives-ouvertes.fr/doctype/Movie",
    "https://data.archives-ouvertes.fr/doctype/Book",
    "https://data.archives-ouvertes.fr/doctype/Article"
];

const languages = [
    "en", "pt", "es", "de", "fr"
];

function getLen(set) {
    var l = 0;
    for (var x of set) {
        l++;
    }
    return l;
}

function getValue(data, i, name) {
    if (name in data[i]) {
        return eval("data[i]." + name + ".value");
    } else {
        return " ";
    }
}

//function getShortName(data, fullname) {
//    var res="";
//    var index;
//    var co;
//    index = data.findIndex(function (ele) {
//        var fullname1 = ele.n1.value;
//        var fullname2 = ele.n2.value;
//        if (fullname1 == fullname) {
//            co = false;
//            return true;
//        }
//        if (fullname2 == fullname) {
//            co = true;
//            return true;
//        }
//    });
//    if (!co) res = getValue(data, index, "c1");
//    else res = getValue(data, index, "c2");
//    return res;
//}

function getShortName(fullname) {
    var words = fullname.split(" ");
    var firstname = words[0];
    var lastname = words[words.length - 1];
    var shortname = firstname[0] + ". " + lastname;
    return shortname;
}

//function getValueByName(data, n, name, co) {
//    var res="";
//    var index;
//    if (!co) {
//        index = data.findIndex(function (ele) {
//            var n0 = ele.n1.value;
//            if (n0==n) {
//                return true;
//            }
//        });
//    } else {
//        index = data.findIndex(function (ele) {
//            var n0 = ele.n2.value;
//            if (n0==n) {
//                return true;
//            }
//        });
//    }
//    res = getValue(data, index, name);
//    return res;
//}

function findQtOneType(data, authorname, typename) {
    var s = 0;
    var index = data.findIndex(function (ele) {
        var n0 = ele.n1.value;
        var t0 = ele.type.value;
        if (n0 == authorname && t0 == typename) {
            s++;
        }
    });
    return s;
}

function findQtPub(qtEachType) {
    var sum = 0;
    for (var i = 0; i < qtEachType.length; i++) {
        sum = sum + Number(qtEachType[i]);
    }
    return sum;
}

function findQtOneTypeCo(data, authorname, coauthorname, typename) {
    var s = 0;
    var index = data.findIndex(function (ele) {
        var na = ele.n1.value;
        var nc = ele.n2.value;
        var t = ele.type.value;
        if (na == authorname && nc == coauthorname && t == typename) {
            s++;
        }
    });
    return s;
}

function findQtOneLanCo(data, authorname, coauthorname, languageName) {
    var s = 0;
    var index = data.findIndex(function (ele) {
        var na = ele.n1.value;
        var nc = ele.n2.value;
        var la = ele.lan.value;
        if (na == authorname && nc == coauthorname && la == languageName) {
            s++;
        }
    });
    return s;
}

function getIdByName(nodes, authorname) {
    for (var i = 0; i < nodes.dataNodes.length; i++) {
        if (nodes.dataNodes[i].labels[1] == authorname) {
            return nodes.dataNodes[i].id;
        }
    }
    return -1;
}

function getNameById(nodes, i) {
    return nodes.dataNodes[i].labels[1];
}

function isInclude(ele, arr) {
    for (var i = 0; i < arr.length; i++) {
        if (ele.authorID == arr[i].authorID && ele.coauthorID == arr[i].coauthorID) {
            return true;
        }
        if (ele.authorID == arr[i].coauthorID && ele.coauthorID == arr[i].authorID) {
            return true;
        }
    }
    return false;
}

function transformType(typeuri) {
    if (typeuri == types[0]) return "conference paper";
    if (typeuri == types[1]) return "report";
    if (typeuri == types[2]) return "preprint";
    return "article";
}

function transformDate(dateuri) {
    dateuri = String(dateuri);
    dateuri = dateuri.replace('\"', "");
    return dateuri.substr(0, 4);
}

function findDocumentInformation(data, nodes) {
    var docList = [];
    var allDocs = [];
    var len = data.length;
    for (var i = 0; i < len; i++) {
        var dc = getValue(data, i, "doc");
        if (!docList.includes(dc)) docList.push(dc);
    }
    for (var i = 0; i < docList.length; i++) {
        var dc = docList[i];
        var index = data.findIndex(function (ele) {
            var d = ele.doc.value;
            if (d == dc) return true;
        });
        if (index !== -1) {
            var tp = transformType(getValue(data, index, "type"));
            var dt = transformDate(getValue(data, index, "date"));
            var tt = getValue(data, index, "title");
            var allAuthors = [];
            for (var j = 0; j < len; j++) {
                var dc2 = getValue(data, j, "doc");
                if (dc == dc2) {
                    var n1 = getValue(data, j, "n1");
                    var n2 = getValue(data, j, "n2");
                    var i1 = getIdByName(nodes, n1);
                    var i2 = getIdByName(nodes, n2);
                    if (!allAuthors.includes(i1)) allAuthors.push(i1);
                    if (!allAuthors.includes(i2)) allAuthors.push(i2);
                }
            }
        }
        allDocs.push({"type": tp, "date": dt, "title": tt, "authors": allAuthors, "link": dc});
    }
    return allDocs;
}

function findCoDoc(docInfo, nodes, authorId, coauthorId) {
    var l = docInfo.length;
    var docArray = [];
    for (var i = 0; i < l; i++) {
        var doc = docInfo[i];
        var dc = doc.link;
        if (doc.authors.includes(authorId) &&
            doc.authors.includes(coauthorId)
        ) docArray.push(doc);
    }
    return docArray;
}

function deleteIrrelativeTypes(data) {
    data = data.filter(function (item) {
        var tp = item.type.value;
        return types.includes(tp);
    });
    return data;
}

function transform(query) {
    query = encodeURIComponent(query);
    query = query.replace(/\%20/g, "+");
    query = query.replace(/\(/g, "%28");
    query = query.replace(/\)/g, "%29");

    var httpquery = "https://data.archives-ouvertes.fr/sparql?default-graph-uri=&query=";
    httpquery = httpquery + query;
    httpquery = httpquery + "&format=application%2Fsparql-results%2Bjson&timeout=0&debug=on&run=+Run+Query+";
    //var httpquery = query;

    var ti1 = new Date();
    var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
    var xmlhttpquery = new XMLHttpRequest();
    xmlhttpquery.open("POST", httpquery, false);
    xmlhttpquery.send();
    var res1 = JSON.parse(xmlhttpquery.responseText);
    var data = res1.results.bindings;
    data = deleteIrrelativeTypes(data);
    var ti2 = new Date();
    //console.log(JSON.stringify(data));
    var len = data.length;

    var numNodes, numEdges;

    var nodes = {
        "labelTitle": ["Short Name", "Author Name", "Category", "Research", "Area"],
        "valueTitle": ["Year Last Pub", "Qt Research", "Qt Area", "Qt Publications",
            "Qt Conference Papers", "Qt Reports", "Qt Articles",
            "Connected Comp.", "Edge BetWeenness", "Closeness Centrality",
            "Betweenness Centrality", "Degree"],
        "imageTitle": null,
        "dataNodes": []
    };
    var edges = {
        "labelTitle": null,
        "valueTitle": ["Qt Publications", "Qt Journals", "Qt Books", "Qt Proceedings",
            "2004", "English", "Portuguese", "Spanish", "German", "French",
            "Research N.I.", "Tolerancia a falhas", "Inteligencia Artificial", "Modelagem Conceitual e BD",
            "Comp. Grafica e P.I.", "Sistemas de Tempo Real", "Arquiteture e Proj. Sist. Comp.", "Microeletronica",
            "Redes de Computadores", "Proc.Paralelo e Distr.", "Metodos formais", "Fundamentos da Computacao", "Engenharia de Software",
            "Sistemas Embarcados", "Teste e Confiabilidade", "TV Digital", "Projeto Isolado",
            "Natureza N.I.", "Trabalho Completo", "Resumo", "Capitulo", "Texto Integral", "Resumo Expandido", "Outro",
            "Area N.I.", "Sistemas de Computacao", "Sistemas de Informacao", "Inteligencia Artificial", "Eng. da Computacao", "Informatica Teorica"],
        "dataEdges": []
    };

    var not = "Not Informed";

    var authorList = [];
    for (var i = 0; i < len; i++) {
        authorList.push(getValue(data, i, "n1"));
        authorList.push(getValue(data, i, "n2"));
    }
    var authorSet = new Set(authorList);
    var id = 0;
    for (var author of authorSet) {
        var shortName = getShortName(author);
        var coauthorList = [];
        for (var j = 0; j < len; j++) {
            if (getValue(data, j, "n1") == author) {
                //&& types.includes(getValue(data, j, "type") )
                coauthorList.push(getValue(data, j, "n2"));
            }
        }
        var coauthorSet = new Set(coauthorList);
        var qtCoauthor = getLen(coauthorSet);
        var qtEachType = [];
        for (var i = 0; i < types.length; i++) {
            qtEachType.push(findQtOneType(data, author, types[i]));
        }
        //var qtPub = findQtPub(qtEachType);

        var nodeInfo = {
            "id": id, "idBD": id, "labels": [shortName, author, not, not, not],
            "values": [2004, 0, 0]
                .concat(qtEachType)
                .concat([qtCoauthor, qtCoauthor, 0.1, 0.1, qtCoauthor / 2 + 1, 1]),
            "images": null
        };
        //if (coauthorList.length != 0) {
        nodes.dataNodes.push(nodeInfo);
        id++;
        //}
    }
    numNodes = id;

    var docInfo = findDocumentInformation(data, nodes);

    var groupList = [];
    for (var i = 0; i < len; i++) {
        var author = getValue(data, i, "n1");
        var authorID = getIdByName(nodes, author);
        var coauthor = getValue(data, i, "n2");
        var coauthorID = getIdByName(nodes, coauthor);
        var obj = {"authorID": authorID, "coauthorID": coauthorID};
        if (coauthorID != -1 && coauthorID < numNodes && !isInclude(obj, groupList)) {
            groupList.push(obj);
        }
    }
    numEdges = getLen(groupList);
    for (var i = 0; i < numEdges; i++) {
        var id1 = groupList[i].authorID;
        var id2 = groupList[i].coauthorID;

        var qtEachTypeCo = [];
        var qtEachLanCo = [];
        for (var j = 0; j < types.length; j++) {
            qtEachTypeCo.push(findQtOneTypeCo(data, getNameById(nodes, id1), getNameById(nodes, id2), types[j]));
        }
        for (var j = 0; j < languages.length; j++) {
            qtEachLanCo.push(findQtOneLanCo(data, getNameById(nodes, id1), getNameById(nodes, id2), languages[j]));
        }
        var qtPubCo = findQtPub(qtEachTypeCo);
        //var _authorname = getNameById(nodes, id1);
        //var _coauthorname = getNameById(nodes, id2);
        var documents = findCoDoc(docInfo, nodes, id1, id2);
        var edgeInfo = {
            "src": id1,
            "tgt": id2,
            "labels": null,
            "values": qtEachTypeCo
                .concat([qtPubCo])
                .concat(qtEachLanCo)
                .concat([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
            "documents": documents
        };

        if (qtPubCo != 0) edges.dataEdges.push(edgeInfo);
    }

    var res2 = {
        "info": {
            "qtNodos": numNodes,
            "qtArestas": numEdges
        },
        "nodes": nodes,
        "edges": edges
    };
    //var zzz = JSON.stringify(res2);
    //var fs = require('fs');
    //fs.writeFile("data.json", zzz, function(err) {
    //    if (err) throw err;
    //    console.log("jsondata saved.");
    //});
    //console.log(JSON.stringify([res1, res2]));
    var ti3 = new Date();
    var stime = parseInt(ti2 - ti1) / 1000;
    var ttime = parseInt(ti3 - ti2) / 1000;
    var total = parseInt(ti3 - ti1) / 1000;
    var res3 = {
        "query_time": stime,
        "trans_time": ttime,
        "total_time": total,
        "res_number": len,
        "node_number": numNodes,
        "edge_number": numEdges,
        "data_type": 1
    }
    //console.log(res3);
    return [res1, res2, res3];
}

function transform2(query) {
    query = encodeURIComponent(query);
    query = query.replace(/\%20/g, "+");
    query = query.replace(/\(/g, "%28");
    query = query.replace(/\)/g, "%29");

    var httpquery = "https://data.archives-ouvertes.fr/sparql?default-graph-uri=&query=";
    httpquery = httpquery + query;
    httpquery = httpquery + "&format=application%2Fsparql-results%2Bjson&timeout=0&debug=on&run=+Run+Query+";
    //var httpquery = query;

    var ti1 = new Date();
    var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
    var xmlhttpquery = new XMLHttpRequest();
    xmlhttpquery.open("POST", httpquery, false);
    xmlhttpquery.send();
    var res1 = JSON.parse(xmlhttpquery.responseText);
    var data = res1.results.bindings;
    data = deleteIrrelativeTypes(data);
    var ti2 = new Date();
    //console.log(JSON.stringify(data));
    var len = data.length;

    var numNodes, numEdges;

    var nodes = {
        "labelTitle": ["Short Name", "Author Name", "Category", "Research", "Area"],
        "valueTitle": ["Year Last Pub", "Qt Research", "Qt Area", "Qt Publications",
            "Qt Conference Papers", "Qt Reports", "Qt Articles",
            "Connected Comp.", "Edge BetWeenness", "Closeness Centrality",
            "Betweenness Centrality", "Degree", "Lab Number"],
        "imageTitle": null,
        "dataNodes": []
    };
    var edges = {
        "labelTitle": null,
        "valueTitle": ["Qt Publications", "Qt Journals", "Qt Books", "Qt Proceedings",
            "2004", "English", "Portuguese", "Spanish", "German", "French",
            "Research N.I.", "Tolerancia a falhas", "Inteligencia Artificial", "Modelagem Conceitual e BD",
            "Comp. Grafica e P.I.", "Sistemas de Tempo Real", "Arquiteture e Proj. Sist. Comp.", "Microeletronica",
            "Redes de Computadores", "Proc.Paralelo e Distr.", "Metodos formais", "Fundamentos da Computacao", "Engenharia de Software",
            "Sistemas Embarcados", "Teste e Confiabilidade", "TV Digital", "Projeto Isolado",
            "Natureza N.I.", "Trabalho Completo", "Resumo", "Capitulo", "Texto Integral", "Resumo Expandido", "Outro",
            "Area N.I.", "Sistemas de Computacao", "Sistemas de Informacao", "Inteligencia Artificial", "Eng. da Computacao", "Informatica Teorica"],
        "dataEdges": []
    };

    var not = "Not Informed";

    var authorList = [];
    for (var i = 0; i < len; i++) {
        authorList.push(getValue(data, i, "n1"));
        authorList.push(getValue(data, i, "n2"));
    }
    var authorSet = new Set(authorList);
    var id = 0;
    for (var author of authorSet) {
        var shortName = getShortName(author);
        var coauthorList1 = [];
        var coauthorList2 = [];
        var isInLab1 = false;
        var isInLab2 = false;
        for (var j = 0; j < len; j++) {
            if (getValue(data, j, "n1") == author) coauthorList1.push(getValue(data, j, "n2"));
            if (getValue(data, j, "n2") == author) coauthorList2.push(getValue(data, j, "n1"));
        }
        if (coauthorList1.length != 0) isInLab1 = true;
        if (coauthorList2.length != 0) isInLab2 = true;
        var lb = 0;
        if (isInLab1 && !isInLab2) lb = 1;
        else if (!isInLab1 && isInLab2) lb = 2;
        else if (isInLab1 && isInLab2) lb = 3;

        var coauthorList = coauthorList1.concat(coauthorList2);
        var coauthorSet = new Set(coauthorList);
        var qtCoauthor = getLen(coauthorSet);
        var qtEachType = [];
        for (var i = 0; i < types.length; i++) {
            qtEachType.push(findQtOneType(data, author, types[i]));
        }
        //var qtPub = findQtPub(qtEachType);

        var nodeInfo = {
            "id": id, "idBD": id, "labels": [shortName, author, not, not, not],
            "values": [2004, 0, 0]
                .concat(qtEachType)
                .concat([qtCoauthor, qtCoauthor, 0.1, 0.1, qtCoauthor / 2 + 1, lb]),
            "images": null
        };
        if (coauthorList.length != 0) {
            nodes.dataNodes.push(nodeInfo);
            id++;
        }
    }
    numNodes = id;

    var docInfo = findDocumentInformation(data, nodes);

    var groupList = [];
    for (var i = 0; i < len; i++) {
        var author = getValue(data, i, "n1");
        var authorID = getIdByName(nodes, author);
        var coauthor = getValue(data, i, "n2");
        var coauthorID = getIdByName(nodes, coauthor);
        var obj = {"authorID": authorID, "coauthorID": coauthorID};
        if (coauthorID != -1 && coauthorID < numNodes && !isInclude(obj, groupList)) {
            groupList.push(obj);
        }
    }
    numEdges = getLen(groupList);
    for (var i = 0; i < numEdges; i++) {
        var id1 = groupList[i].authorID;
        var id2 = groupList[i].coauthorID;

        var qtEachTypeCo = [];
        var qtEachLanCo = [];
        for (var j = 0; j < types.length; j++) {
            qtEachTypeCo.push(findQtOneTypeCo(data, getNameById(nodes, id1), getNameById(nodes, id2), types[j]));
        }
        for (var j = 0; j < languages.length; j++) {
            qtEachLanCo.push(findQtOneLanCo(data, getNameById(nodes, id1), getNameById(nodes, id2), languages[j]));
        }
        var qtPubCo = findQtPub(qtEachTypeCo);
        //var _authorname = getNameById(nodes, id1);
        //var _coauthorname = getNameById(nodes, id2);
        var documents = findCoDoc(docInfo, nodes, id1, id2);
        var edgeInfo = {
            "src": id1,
            "tgt": id2,
            "labels": null,
            "values": qtEachTypeCo
                .concat([qtPubCo])
                .concat(qtEachLanCo)
                .concat([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
            "documents": documents
        };

        if (qtPubCo != 0) edges.dataEdges.push(edgeInfo);
    }

    var res2 = {
        "info": {
            "qtNodos": numNodes,
            "qtArestas": numEdges
        },
        "nodes": nodes,
        "edges": edges
    };
    //var zzz = JSON.stringify(res2);
    //var fs = require('fs');
    //fs.writeFile("data.json", zzz, function(err) {
    //    if (err) throw err;
    //    console.log("jsondata saved.");
    //});
    //console.log(JSON.stringify([res1, res2]));
    var ti3 = new Date();
    var stime = parseInt(ti2 - ti1) / 1000;
    var ttime = parseInt(ti3 - ti2) / 1000;
    var total = parseInt(ti3 - ti1) / 1000;
    var res3 = {
        "query_time": stime,
        "trans_time": ttime,
        "total_time": total,
        "res_number": len,
        "node_number": numNodes,
        "edge_number": numEdges,
        "data_type": 2
    }
    //console.log(res3);
    return [res1, res2, res3];
}

function sparql(query) {
    //query = encodeURIComponent(query);
    //query = query.replace(/\%20/g,"+");
    //query = query.replace(/\(/g, "%28");
    //query = query.replace(/\)/g, "%29");

    //var httpquery = "https://data.archives-ouvertes.fr/sparql?default-graph-uri=&query=";
    //httpquery = httpquery + query;
    //httpquery = httpquery + "&format=application%2Fsparql-results%2Bjson&timeout=0&debug=on&run=+Run+Query+";
    var httpquery = query;
    //console.log(httpquery);

    var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
    var xmlhttpquery = new XMLHttpRequest();
    xmlhttpquery.open("POST", httpquery, false);
    xmlhttpquery.send();
    //console.log(xmlhttpquery.responseText);
    var res = JSON.parse(xmlhttpquery.responseText);
    //console.log(res);
    return res;
}

module.exports = {transform, transform2, sparql};

//var qur = "http://sparql.archives-ouvertes.fr/sparql?default-graph-uri=&query=prefix+skos%3A+%3Chttp%3A%2F%2Fwww.w3.org%2F2004%2F02%2Fskos%2Fcore%23%3E%0D%0Aprefix+org%3A+%3Chttp%3A%2F%2Fwww.w3.org%2Fns%2Forg%23%3E%0D%0Aprefix+hsc%3A+%3Chttp%3A%2F%2Fdata.archives-ouvertes.fr%2Fschema%2F%3E%0D%0Aprefix+dc%3A+%3Chttp%3A%2F%2Fpurl.org%2Fdc%2Fterms%2F%3E%0D%0Aprefix+dct%3A+%3Chttp%3A%2F%2Fpurl.org%2Fdc%2Felements%2F1.1%2F%3E%0D%0Aprefix+org%3A++%3Chttp%3A%2F%2Fwww.w3.org%2Fns%2Forg%3E%0D%0Aprefix+lab%3A++%3Chttp%3A%2F%2Fwww.unice.fr%2Fother%2F%3E%0D%0Aprefix+inr%3A++%3Chttp%3A%2F%2Fns.inria.fr%2Fsparql-extension%2Fuser%2F%3E%0D%0Aprefix+vs%3A++%3Chttp%3A%2F%2Fwww.w3.org%2F2006%2Fvcard%2Fns%23%3E%0D%0Aprefix+db%3A+%3Chttp%3A%2F%2Ffr.dbpedia.org%2Fresource%2F%3E%0D%0Aprefix+dbo%3A+%3Chttp%3A%2F%2Ffr.dbpedia.org%2Fontology%2F%3E%0D%0Aprefix+o%3A+%3Chttp%3A%2F%2Fdbpedia.org%2Fontology%2F%3E%0D%0Aprefix+geo%3A+%3Chttp%3A%2F%2Fwww.w3.org%2F2003%2F01%2Fgeo%2Fwgs84_pos%23%3E%0D%0Aprefix+foaf%3A++%3Chttp%3A%2F%2Fxmlns.com%2Ffoaf%2F0.1%2F%3E%0D%0A%0D%0Aselect+%3Fc1+%3Fn1+%3Fd1+%3Fc2+%3Fn2+%3Fd2+%3Fdoc+%3Fdate+%3Ftitle+%3Ftype+%3Flan+where+%0D%0A%7B%0D%0A++++++++%3Fdoc+dc%3Acreator+%3Fs1+.%0D%0A++++++++%3Fdoc+dc%3Acreator+%3Fs2+.%0D%0A++++++++%3Fdoc+dc%3Atype+%3Ftype+.%0D%0A++++++++%3Fdoc+dc%3Atitle+%3Ftitle+.%0D%0A++++++++%3Fdoc+dct%3Alanguage+%3Flan+.%0D%0A++++++++%3Fdoc+dc%3Aissued+%3Fdate+.%0D%0A++++++++filter+%28%3Flan+%3D+%22en%22+%7C%7C+%3Flan+%3D+%22fr%22+%7C%7C+%3Flan+%3D+%22de%22+%7C%7C+%3Flan+%3D+%22pt%22+%7C%7C+%3Flan+%3D+%22es%22%29+%0D%0A++++++++filter+%28%3Fs1+%21%3D+%3Fs2%29%0D%0A++++++++%3Fs1+hsc%3Astructure+%3Fx1+.%0D%0A++++++++%3Fs2+hsc%3Astructure+%3Fx2+.%0D%0A++++++++%3Fx1+org%3AunitOf%2A+%3Fsam+.%0D%0A++++++++%3Fx2+org%3AunitOf%2A+%3Fsam+.%0D%0A++++++++%3Fsam+skos%3AprefLabel+%22Laboratoire+d%27Informatique%2C+Signaux%2C+et+Syst%C3%A8mes+de+Sophia+Antipolis%22+.%0D%0A%0D%0A++++++++%3Fs1+hsc%3Aperson+%3Fp1+.%0D%0A++++++++%3Fp1+foaf%3Aname+%3Fn1+.%0D%0A++++++++%3Fp1+foaf%3AfirstName+%3Fa1+.%0D%0A++++++++%3Fp1+foaf%3AfamilyName+%3Fb1+.%0D%0A++++++++++++++++++%0D%0A++++++++%3Fs2+hsc%3Aperson+%3Fp2+.%0D%0A++++++++%3Fp2+foaf%3Aname+%3Fn2+.%0D%0A++++++++%3Fp2+foaf%3AfirstName+%3Fa2+.%0D%0A++++++++%3Fp2+foaf%3AfamilyName+%3Fb2+.%0D%0A++++++++optional+%7B%3Fp1+foaf%3Ahomepage+%3Fd1%7D%0D%0A++++++++optional+%7B%3Fp2+foaf%3Ahomepage+%3Fd2%7D%0D%0A++++++++bind%28concat%28substr%28%3Fa1%2C1%2C1%29%2C%22.+%22%2C+%3Fb1%29+as+%3Fc1%29+.%0D%0A++++++++bind%28concat%28substr%28%3Fa2%2C1%2C1%29%2C%22.+%22%2C+%3Fb2%29+as+%3Fc2%29+.+%0D%0A%7D++++++++++++%0D%0A%23+limit+100&format=application%2Fsparql-results%2Bjson&timeout=0&debug=on&run=+Run+Query+"
//transform(qur);
