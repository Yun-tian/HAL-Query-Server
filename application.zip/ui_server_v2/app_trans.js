var http = require('http');

var server = http.createServer(function (req, res) {
console.log(req.url);
    var q = '';
    var f = '';
    var l = '';
    var by = '';
    var ey = '';
    //var tst = "https://data.archives-ouvertes.fr/sparql?default-graph-uri=&query=prefix+skos%3A+%3Chttp%3A%2F%2Fwww.w3.org%2F2004%2F02%2Fskos%2Fcore%23%3E%0D%0Aprefix+org%3A+%3Chttp%3A%2F%2Fwww.w3.org%2Fns%2Forg%23%3E%0D%0Aprefix+hsc%3A+%3Chttp%3A%2F%2Fdata.archives-ouvertes.fr%2Fschema%2F%3E%0D%0Aprefix+dc%3A++%3Chttp%3A%2F%2Fpurl.org%2Fdc%2Fterms%2F%3E%0D%0Aprefix+dct%3A+%3Chttp%3A%2F%2Fpurl.org%2Fdc%2Felements%2F1.1%2F%3E%0D%0Aprefix+org%3A+%3Chttp%3A%2F%2Fwww.w3.org%2Fns%2Forg%3E%0D%0Aprefix+lab%3A+%3Chttp%3A%2F%2Fwww.unice.fr%2Fother%2F%3E%0D%0Aprefix+inr%3A+%3Chttp%3A%2F%2Fns.inria.fr%2Fsparql-extension%2Fuser%2F%3E%0D%0Aprefix+vs%3A++%3Chttp%3A%2F%2Fwww.w3.org%2F2006%2Fvcard%2Fns%23%3E%0D%0Aprefix+db%3A++%3Chttp%3A%2F%2Ffr.dbpedia.org%2Fresource%2F%3E%0D%0Aprefix+dbo%3A+%3Chttp%3A%2F%2Ffr.dbpedia.org%2Fontology%2F%3E%0D%0Aprefix+o%3A+++%3Chttp%3A%2F%2Fdbpedia.org%2Fontology%2F%3E%0D%0Aprefix+geo%3A+%3Chttp%3A%2F%2Fwww.w3.org%2F2003%2F01%2Fgeo%2Fwgs84_pos%23%3E%0D%0Aprefix+foaf%3A+%3Chttp%3A%2F%2Fxmlns.com%2Ffoaf%2F0.1%2F%3E%0D%0A%0D%0A++++select+%3Fc1+%3Fn1+%3Fd1+%3Fc2+%3Fn2+%3Fd2+%3Ftype+%28count+%28%3Fdoc%29+as+%3Fqttype%29+%3Flan+%28count+%28%3Fdoc%29+as+%3Fqtlan%29+where+%7B%0D%0A++++++++%3Fdoc+dc%3Acreator+%3Fs1+.%0D%0A++++++++%3Fdoc+dc%3Acreator+%3Fs2+.%0D%0A++++++++%3Fdoc+dc%3Atype+%3Ftype+.%0D%0A++++++++%3Fdoc+dct%3Alanguage+%3Flan+.%0D%0A++++++++filter+%28%3Flan+%3D+%22en%22+%7C%7C+%3Flan+%3D+%22fr%22+%7C%7C+%3Flan+%3D+%22de%22+%7C%7C+%3Flan+%3D+%22pt%22+%7C%7C+%3Flan+%3D+%22es%22%29%0D%0A++++++++filter+%28%3Fs1+%21%3D+%3Fs2+%29%0D%0A++++++++%3Fs1+hsc%3Astructure+%3Fx1+.%0D%0A++++++++%3Fs2+hsc%3Astructure+%3Fx2+.%0D%0A++++++++%3Fx1+org%3AunitOf*+%3Fsam+.%0D%0A++++++++%3Fx2+org%3AunitOf*+%3Fsam+.%0D%0A++++++++%3Fsam+skos%3AprefLabel+%22Laboratoire+d%27Informatique%2C+Signaux%2C+et+Syst%C3%A8mes+de+Sophia+Antipolis%22+.%0D%0A%0D%0A++++++++%3Fs1+hsc%3Aperson+%3Fp1+.%0D%0A++++++++%3Fp1+foaf%3Aname+%3Fn1+.%0D%0A++++++++%3Fp1+foaf%3AfirstName+%3Fa1+.%0D%0A++++++++%3Fp1+foaf%3AfamilyName+%3Fb1+.%0D%0A++++++++%0D%0A++++++++%3Fs2+hsc%3Aperson+%3Fp2+.%0D%0A++++++++%3Fp2+foaf%3Aname+%3Fn2+.%0D%0A++++++++%3Fp2+foaf%3AfirstName+%3Fa2+.%0D%0A++++++++%3Fp2+foaf%3AfamilyName+%3Fb2+.%0D%0A%0D%0A++++++++optional+%7B+%3Fp1+foaf%3Ahomepage+%3Fd1+%7D%0D%0A++++++++optional+%7B+%3Fp2+foaf%3Ahomepage+%3Fd2+%7D%0D%0A%0D%0A++++++++bind%28concat%28substr%28%3Fa1%2C1%2C1%29%2C%22.+%22%2C%3Fb1%29+as+%3Fc1%29+.%0D%0A++++++++bind%28concat%28substr%28%3Fa2%2C1%2C1%29%2C%22.+%22%2C%3Fb2%29+as+%3Fc2%29+.%0D%0A++++++++%0D%0A++++%7D%0D%0A++++group+by+%3Fc1+%3Fn1+%3Fd1+%3Fc2+%3Fn2+%3Fd2+%3Ftype+%3Flan%0D%0A++++%23+limit+100&format=application%2Fsparql-results%2Bjson&timeout=0&debug=on&run=+Run+Query+";
    req.on('data', function(str) {
        var data = JSON.parse(str);
        q = data.query;
        f = data.format;
        l = data.lab;
        by = data.beginYear;
        ey = data.endYear;
        //console.log("q = " + q);
        //console.log("f = " + f);
        //console.log("l = " + l);
        q = q.replace(/param/,l);
        q = q.replace(/beginYear/,by);
        q = q.replace(/endYear/,ey);
    });
    req.on('end', function() {
        res.writeHeader(200, { 'Content-Type': 'text/plain', 'Access-Control-Allow-Origin': '*'});
        var iris = require("./trans_vidas");
        var mg4 = require("./trans_mg4");
        var res1;
        var res2;
        if (f == "VIDAS") {
            result = iris.transform(q);
        } else {
            result = mg4.transform(q);
        }
        result = JSON.stringify(result);
        // Save json file
        var fs = require('fs');
        //fs.writeFile("data.json", result, function(err) {
        //    if (err) throw err;
        //    console.log("jsondata saved.");
        //});
        fs.writeFile("./MG-Explorer/json/data.json", res1, function(err) {
            if (err) throw err;
            console.log("jsondata saved in MGExplorer library.");
        });
        res.write(result);
        res.end();
    })
});
server.listen(8090,"134.59.130.139", function () { console.log('Transforming server start at 134.59.130.139:8090'); });
