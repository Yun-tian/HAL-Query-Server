define( ["d3"], function (d3) {

  return function LinkView () {


	function linkView() {}

//---------------------		
	linkView.create = function (x, y, config) {
	};
	
//---------------------		
	 return linkView;
	 
  }


});
