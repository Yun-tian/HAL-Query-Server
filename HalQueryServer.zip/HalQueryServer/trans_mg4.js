// Default types in HAL Query: Conference Paper, Report, Book, Article
// which will be (however) showed as : Publication, Journal, Book, Proceeding
const types = [
    "https://data.archives-ouvertes.fr/doctype/ConferencePaper",
    //"https://data.archives-ouvertes.fr/doctype/Chapter",
    //"https://data.archives-ouvertes.fr/doctype/Douv",
    //"https://data.archives-ouvertes.fr/doctype/Hdr",
    //"https://data.archives-ouvertes.fr/doctype/Image",
    //"https://data.archives-ouvertes.fr/doctype/LectureNotes",
    //"https://data.archives-ouvertes.fr/doctype/Map",
    //"https://data.archives-ouvertes.fr/doctype/Mem",
    //"https://data.archives-ouvertes.fr/doctype/Minutes",
    //"https://data.archives-ouvertes.fr/doctype/Other",
    //"https://data.archives-ouvertes.fr/doctype/Otherreport",
    //"https://data.archives-ouvertes.fr/doctype/Ouv",
    //"https://data.archives-ouvertes.fr/doctype/Patent",
    //"https://data.archives-ouvertes.fr/doctype/ConferencePoster",
    //"https://data.archives-ouvertes.fr/doctype/Presconf",
    //"https://data.archives-ouvertes.fr/doctype/Repact",
    "https://data.archives-ouvertes.fr/doctype/Report",
    //"https://data.archives-ouvertes.fr/doctype/AudioDocument",
    //"https://data.archives-ouvertes.fr/doctype/Synthese",
    //"https://data.archives-ouvertes.fr/doctype/DoctoralThesis",
    //"https://data.archives-ouvertes.fr/doctype/Preprint",
    //"https://data.archives-ouvertes.fr/doctype/Movie",
    "https://data.archives-ouvertes.fr/doctype/Book",
    "https://data.archives-ouvertes.fr/doctype/Article"
];

const languages = [
    "en", "pt", "es", "de", "fr"
];

// demander la longueur d'un set
// set : Javascript Set
// $return : la longueur du Set (integer)
function getLen(set) {
    var l = 0;
    for (var x of set) {
        l++;
    }
    return l;
}

// demander une valeur dans le résultat SPARQL
// data : résultat SPARQL
// i : indice de data (number, integer)
// name : nom de la variable (n1, n2, doc, title, ...)
function getValue(data, i, name) {
    if (name in data[i]) {
        return eval("data[i]." + name + ".value");
    } else {
        return " ";
    }
}

// prendre le nom complète d'un auteur et donner son nom abbrégé (par ex. getShortName("Yun Tian") = "Y. Tian" )
// à optimiser : getShortName("Catherine Faron Zucker") donne "C. Zucker" mais "C. Faron Zucker" est attendu
function getShortName(fullname) {
    var words = fullname.split(" ");
    var firstname = words[0];
    var lastname = words[words.length - 1];
    var shortname = firstname[0] + ". " + lastname;
    return shortname;
}

// trouver la quantité de publications à un type d'un auteur
// data : résultat SPARQL
// authorname : nom complet de l'auteur (string)
// typename : nom du type de document (string, en uri)
// $return : la quantité de publications de l'auteur à un certain type (number, integer)
function findQtOneType(data, authorname, typename) {
    var s = 0;
    var index = data.findIndex(function (ele) {
        var n0 = ele.n1.value;
        var t0 = ele.type.value;
        if (n0 == authorname && t0 == typename) {
            s++;
        }
    });
    return s;
}

// Calculer la quantité totale de publications d'un auteur ou de copublications entre deux auteurs
// qtEachType : vecteur à longueur 4 (Array of number, integer)
// $return : la somme des chiffres dans l'Array (number, integer)
function findQtPub(qtEachType) {
    var sum = 0;
    for (var i = 0; i < qtEachType.length; i++) {
        sum = sum + Number(qtEachType[i]);
    }
    return sum;
}

// Trouver la quantité de copublications à un certain type entre deux auteurs
// data : résultat SPARQL
// authorname : nom complet de l'auteur (string)
// coauthorname : nom complet du coauteur (string)
// typename : nom du type de document (string, en uri)
// $return : la quantité de copublications à un certain type entre deux auteurs (number, integer)
function findQtOneTypeCo(data, authorname, coauthorname, typename) {
    var s = 0;
    var index = data.findIndex(function (ele) {
        var na = ele.n1.value;
        var nc = ele.n2.value;
        var t = ele.type.value;
        if (na == authorname && nc == coauthorname && t == typename) {
            s++;
        }
    });
    return s;
}

// Trouver la quantité de copublications en certaine langue entre deux auteurs
// data : résultat SPARQL
// authorname : nom complet de l'auteur (string)
// coauthorname : nom complet du coauteur (string)
// languageName : nom de la langue (string)
// $return : la quantité de copublications en certaine langue entre deux auteurs (number, integer)
function findQtOneLanCo(data, authorname, coauthorname, languageName) {
    var s = 0;
    var index = data.findIndex(function (ele) {
        var na = ele.n1.value;
        var nc = ele.n2.value;
        var la = ele.lan.value;
        if (na == authorname && nc == coauthorname && la == languageName) {
            s++;
        }
    });
    return s;
}

// Retrouver l'id d'un auteur à partir de son nom (pendant la création des Edges)
// nodes : objet créé pendant la transformation
// authorname : nom complet de l'auteur (string)
// $return : l'id de l'auteur dans nodes, -1 si aucun résultat correspondant. (number, integer)
function getIdByName(nodes, authorname) {
    for (var i = 0; i < nodes.dataNodes.length; i++) {
        if (nodes.dataNodes[i].labels[1] == authorname) {
            return nodes.dataNodes[i].id;
        }
    }
    return -1;
}

// Trouver le nom complet d'un auteur à partir de son id dans nodes
// nodes : objet créé pendant la transformation
// i : l'id de l'auteur (number, integer)
// $return : nom complet de l'auteur (string)
function getNameById(nodes, i) {
    return nodes.dataNodes[i].labels[1];
}

// Transformer l'uri de type vers une chaîne de caractère simple
function transformType(typeuri) {
    if (typeuri == types[0]) return "conference paper";
    if (typeuri == types[1]) return "report";
    if (typeuri == types[2]) return "preprint";
    return "article";
}

// Transformer le format spéciale d'une date vers l'année en 4 chiffres ($return string)
function transformDate(dateuri) {
    dateuri = String(dateuri);
    dateuri = dateuri.replace('\"', "");
    return dateuri.substr(0, 4);
}

// Fonction développée pour visualiser les données demandées par la technique "Papers' List"
// data : résultat SPARQL
// nodes : objet créé pendant la transformation
// $return : un Array dont chaque élément (objet) représente un document avec toutes ses informations
function findDocumentInformation(data, nodes) {
    var docList = []; // contiendra les URIs de tous les documents
    var allDocs = []; // contiendra les documents avec leurs informations en détail
    var len = data.length;
    for (var i = 0; i < len; i++) {
        var dc = getValue(data, i, "doc");
        if (!docList.includes(dc)) docList.push(dc);
    }
    for (var i = 0; i < docList.length; i++) { // trouver tous les auteurs de chaque document
        var dc = docList[i];
        var index = data.findIndex(function (ele) {
            var d = ele.doc.value;
            if (d == dc) return true;
        });
        if (index !== -1) {
            var tp = transformType(getValue(data, index, "type"));
            var dt = transformDate(getValue(data, index, "date"));
            var tt = getValue(data, index, "title");
            var allAuthors = [];
            for (var j = 0; j < len; j++) {
                var dc2 = getValue(data, j, "doc");
                if (dc == dc2) {
                    var n1 = getValue(data, j, "n1");
                    var n2 = getValue(data, j, "n2");
                    var i1 = getIdByName(nodes, n1);
                    var i2 = getIdByName(nodes, n2);
                    if (!allAuthors.includes(i1)) allAuthors.push(i1);
                    if (!allAuthors.includes(i2)) allAuthors.push(i2);
                }
            }
        }
        allDocs.push({"type": tp, "date": dt, "title": tt, "authors": allAuthors, "link": dc});
    }
    return allDocs;
}

// docInfo : Array créé par la fonction findDocumentInformation
// nodes : Array créé pendant la transformation
// authorId : l'id de l'auteur dans nodes
// coauthorId : l'id du coauteur dans nodes
// $return : les documents que les 2 auteurs ont copubliés (sous-ensemble de docInfo)
function findCoDoc(docInfo, nodes, authorId, coauthorId) {
    var l = docInfo.length;
    var docArray = [];
    for (var i = 0; i < l; i++) {
        var doc = docInfo[i];
        var dc = doc.link;
        if (doc.authors.includes(authorId) &&
            doc.authors.includes(coauthorId)
        ) docArray.push(doc);
    }
    return docArray;
}

// Filtrer les résultats SPARQL dont le type du document ne correspond pas aux 4 types choisis
function deleteIrrelativeTypes(data) {
    data = data.filter(function (item) {
        var tp = item.type.value;
        return types.includes(tp);
    });
    return data;
}

// Fonction main exportée
// query : la requête SPARQL
function transform(query, q_type) {
    // Encodage de la requête
    query = encodeURIComponent(query);
    query = query.replace(/\%20/g, "+");
    query = query.replace(/\(/g, "%28");
    query = query.replace(/\)/g, "%29");

    // Configurer la requête SPARQL en format http
    var httpquery = "https://data.archives-ouvertes.fr/sparql?default-graph-uri=&query=";
    httpquery = httpquery + query;
    httpquery = httpquery + "&format=application%2Fsparql-results%2Bjson&timeout=0&debug=on&run=+Run+Query+";


    var ti1 = new Date();
    var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
    var xmlhttpquery = new XMLHttpRequest();
    xmlhttpquery.open("POST", httpquery, false);
    xmlhttpquery.send();
    var res1 = JSON.parse(xmlhttpquery.responseText); // Résultat brut de la requête SPARQL
    var data = res1.results.bindings; // Les vraies données sont dans res1.results.bindings
    data = deleteIrrelativeTypes(data); // Enlever les données avec d'autres types de document
    var ti2 = new Date();
    //console.log(JSON.stringify(data));
    var len = data.length;

    var numNodes, numEdges;

    // Créer le corps de l'objet json par rapport au format attendu par MG-Explorer
    // Les données seront remplies dans "dataNodes" et "dataEdges"
    var nodes = {
        "labelTitle": ["Short Name", "Author Name", "Category", "Research", "Area"],
        "valueTitle": ["Year Last Pub", "Qt Research", "Qt Area", "Qt Publications",
            "Qt Journals", "Qt Books", "Qt Proceedings",
            "Connected Comp.", "Edge BetWeenness", "Closeness Centrality",
            "Betweenness Centrality", "Degree"],
        "imageTitle": null,
        "dataNodes": []
    };
    var edges = {
        "labelTitle": null,
        "valueTitle": ["Qt Publications", "Qt Journals", "Qt Books", "Qt Proceedings",
            "2004", "English", "Portuguese", "Spanish", "German", "French",
            "Research N.I.", "Tolerancia a falhas", "Inteligencia Artificial", "Modelagem Conceitual e BD",
            "Comp. Grafica e P.I.", "Sistemas de Tempo Real", "Arquiteture e Proj. Sist. Comp.", "Microeletronica",
            "Redes de Computadores", "Proc.Paralelo e Distr.", "Metodos formais", "Fundamentos da Computacao", "Engenharia de Software",
            "Sistemas Embarcados", "Teste e Confiabilidade", "TV Digital", "Projeto Isolado",
            "Natureza N.I.", "Trabalho Completo", "Resumo", "Capitulo", "Texto Integral", "Resumo Expandido", "Outro",
            "Area N.I.", "Sistemas de Computacao", "Sistemas de Informacao", "Inteligencia Artificial", "Eng. da Computacao", "Informatica Teorica"],
        "dataEdges": []
    };

    var not = "Not Informed"; // Remplir aux termes non-obligatoires

    var authorList = [];
    for (var i = 0; i < len; i++) {
        authorList.push(getValue(data, i, "n1"));
        authorList.push(getValue(data, i, "n2"));
    }
    var authorSet = new Set(authorList); // Trouver tous les noms d'auteur à partir de data
    var id = 0;
    var lb = 1;
    if (q_type == 1) { // Pour la requête 1
        for (var author of authorSet) {
            var shortName = getShortName(author);
            var coauthorList = [];
            for (var j = 0; j < len; j++) {
                if (getValue(data, j, "n1") == author) {
                    coauthorList.push(getValue(data, j, "n2"));
                }
            }
            var coauthorSet = new Set(coauthorList);
            var qtCoauthor = getLen(coauthorSet);
            var qtEachType = [];
            for (var i = 0; i < types.length; i++) {
                qtEachType.push(findQtOneType(data, author, types[i]));
            }
            var nodeInfo = {
                "id": id, "idBD": id, "labels": [shortName, author, not, not, not],
                "values": [2004, 0, 0]
                    .concat(qtEachType)
                    .concat([qtCoauthor, qtCoauthor, 0.1, 0.1, qtCoauthor / 2 + 1, lb]),
                "images": null
            };
            if (coauthorList.length != 0) {
                nodes.dataNodes.push(nodeInfo);
                id++;
            }
        }
    }
    else { // Pour la requête 2 ou 3
        for (var author of authorSet) {
            var shortName = getShortName(author);
            var coauthorList1 = [];
            var coauthorList2 = [];
            var isInLab1 = false;
            var isInLab2 = false;
            for (var j = 0; j < len; j++) {
                if (getValue(data, j, "n1") == author) coauthorList1.push(getValue(data, j, "n2"));
                if (getValue(data, j, "n2") == author) coauthorList2.push(getValue(data, j, "n1"));
            }
            if (coauthorList1.length != 0) isInLab1 = true;
            if (coauthorList2.length != 0) isInLab2 = true;
            if (isInLab1 && !isInLab2) lb = 1;
            else if (!isInLab1 && isInLab2) lb = 2;
            else if (isInLab1 && isInLab2) lb = 3;
            var coauthorList = coauthorList1.concat(coauthorList2);
            var coauthorSet = new Set(coauthorList);
            var qtCoauthor = getLen(coauthorSet);
            var qtEachType = [];
            for (var i = 0; i < types.length; i++) {
                qtEachType.push(findQtOneType(data, author, types[i]));
            }
            var nodeInfo = {
                "id": id, "idBD": id, "labels": [shortName, author, not, not, not],
                "values": [2004, 0, 0]
                    .concat(qtEachType)
                    .concat([qtCoauthor, qtCoauthor, 0.1, 0.1, qtCoauthor / 2 + 1, lb]),
                "images": null
            };
            if (coauthorList.length != 0) {
                nodes.dataNodes.push(nodeInfo);
                id++;
            }
        }
    }
    numNodes = id;

    var docInfo = findDocumentInformation(data, nodes); // tous les documents avec leurs informations détaillées

    var groupList = []; // contiendra les paires [author, coauthor]
    for (var i = 0; i < len; i++) {
        var author = getValue(data, i, "n1");
        var authorID = getIdByName(nodes, author);
        var coauthor = getValue(data, i, "n2");
        var coauthorID = getIdByName(nodes, coauthor);
        var obj = {"authorID": authorID, "coauthorID": coauthorID};
        if (coauthorID != -1 && coauthorID < numNodes && !groupList.includes(obj)) {
            groupList.push(obj);
        }
    }
    numEdges = getLen(groupList);
    for (var i = 0; i < numEdges; i++) { // Fabriquer les informations des Edges
        var id1 = groupList[i].authorID;
        var id2 = groupList[i].coauthorID;

        var qtEachTypeCo = [];
        var qtEachLanCo = [];
        for (var j = 0; j < types.length; j++) {
            qtEachTypeCo.push(findQtOneTypeCo(data, getNameById(nodes, id1), getNameById(nodes, id2), types[j]));
        }
        for (var j = 0; j < languages.length; j++) {
            qtEachLanCo.push(findQtOneLanCo(data, getNameById(nodes, id1), getNameById(nodes, id2), languages[j]));
        }
        var qtPubCo = findQtPub(qtEachTypeCo);
        var documents = findCoDoc(docInfo, nodes, id1, id2);
        var edgeInfo = {
            "src": id1,
            "tgt": id2,
            "labels": null,
            "values": qtEachTypeCo
                .concat([qtPubCo])
                .concat(qtEachLanCo)
                .concat([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
            "documents": documents
        };
        if (qtPubCo != 0) edges.dataEdges.push(edgeInfo);
    }

    var res2 = {
        "info": {
            "qtNodos": numNodes,
            "qtArestas": numEdges
        },
        "nodes": nodes,
        "edges": edges
    };
    var ti3 = new Date();
    var stime = parseInt(ti2 - ti1) / 1000;
    var ttime = parseInt(ti3 - ti2) / 1000;
    var total = parseInt(ti3 - ti1) / 1000;
    var res3 = {
        "query_time": stime,
        "trans_time": ttime,
        "total_time": total,
        "res_number": len,
        "node_number": numNodes,
        "edge_number": numEdges,
        "data_type": lb
    }
    return [res1, res2, res3];
    // res1 : Résultat SPARQL en JSON
    // res2 : Résultat de la transformation en JSON
    // res3 : Informations supplémentaires (temps d'exécution, statistiques)
}

function sparql(query) {
    //query = encodeURIComponent(query);
    //query = query.replace(/\%20/g,"+");
    //query = query.replace(/\(/g, "%28");
    //query = query.replace(/\)/g, "%29");

    //var httpquery = "https://data.archives-ouvertes.fr/sparql?default-graph-uri=&query=";
    //httpquery = httpquery + query;
    //httpquery = httpquery + "&format=application%2Fsparql-results%2Bjson&timeout=0&debug=on&run=+Run+Query+";
    var httpquery = query;
    //console.log(httpquery);

    var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
    var xmlhttpquery = new XMLHttpRequest();
    xmlhttpquery.open("POST", httpquery, false);
    xmlhttpquery.send();
    //console.log(xmlhttpquery.responseText);
    var res = JSON.parse(xmlhttpquery.responseText);
    //console.log(res);
    return res;
}

module.exports = {transform};