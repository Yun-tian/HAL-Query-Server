// À configurer si nécessaire
var port = 8080
//var documentRoot = '/home/yuntian/Desktop/HalQueryServer';  // chemin dans la VM
var documentRoot = '/home/user/WebstormProjects/HalQueryServer'; // chemin dans la machine de Yun



var http = require('http');
var fs = require('fs');

// Renvoie le nom français d'un pays à partir de son nom anglais
function getFrenchName(country) {
    if (country == "France") return "France";
    if (country == "United Kingdom") return "Royaume-Uni";
    if (country == "United States") return "États-Unis";
    if (country == "Spain") return "Espagne";
    if (country == "Germany") return "Allemagne";
    if (country == "Italy") return "Italie";
    if (country == "Portugal") return "Portugal";
    if (country == "China") return "Chine";
    if (country == "Japan") return "Japon";
    if (country == "Vietnam") return "Vietnam";
    if (country == "Russia") return "Russie";
    if (country == "Brazil") return "Brésil";
    if (country == "Mexico") return "Mexique";
    if (country == "Morocco") return "Maroc";
    return "unknown";
}

// serveur qui écoute le port 8080
var server = http.createServer(function (req, res) {
    var url = req.url;
    //console.log(url);

    // Si l'url de la requête http n'est pas vide, il s'agit un fichier à importer.
    // Il est soit la page "index.html" soit un fichier (en css, js, png, etc.) à importer sur la page
    if (url != "/") {
        var file = documentRoot + url;
        fs.readFile(file, function (err, data) {
            if (err) { // en cas de fichier introuvable
                res.writeHeader(404, {
                    'content-type': 'text/html;charset="utf-8"'
                });
                res.write("<h1>404 Forbidden</h1><p>The page does not exist.</p>");
                res.end();
            } else { // au cas où le fichier est bien trouvé
                var extName = url.substring(url.lastIndexOf(".")).toLowerCase();
                switch (extName) { // écrire le code html qui fait importer les fichiers par rapport à leur type
                    case ".js":
                        res.writeHeader(200, {'content-type': 'text/javascript;charset="utf-8"'});
                        break;
                    case ".css":
                        res.writeHeader(200, {'content-type': 'text/css;charset="utf-8"'});
                        break;
                    case ".png":
                        res.writeHeader(200, {'content-type': 'image/png'});
                        break;
                    case ".ico":
                        res.writeHeader(200, {'content-type': 'image/x-icon'});
                        break;
                    default:
                        // Imprimer l'info à chaque fois le site est visitée
                        var T = new Date();
                        console.log("The website is visited at " + T + ".");
                        res.writeHeader(200, {'content-type': 'text/html;charset="utf-8"'});
                }
                res.write(data);
                res.end();
            }
        });
    } else {
        // S'il n'existe pas l'url dans la requête http, alors il s'agit de l'envoi d'une requête SPARQL
        // Le serveur reçoit la requête en JSON (chaîne de caractères) dont le format est:
        // {"q": requête SPARQL, "f": format de données, (les termes à remplacer, les noms et les années dans q), "type":numéro de la requête}

        var sttt = '';      // contenu de la requête (objet transformé en string)
        var q = '';         // requête SPARQL
        var f = '';         // format de données, seulement MG-Explorer pour cette version
        var l = '';         // dans Q1 et Q3, nom du laboratoire
        var l1 = '';        // dans Q2, nom du laboratoire 1
        var l2 = '';        // dans Q2, nom du laboratoire 2
        var c = '';         // dans Q3, nom du pays
        var by = '';        // année début
        var ey = '';        // année fin
        var qt;             // type de requête (1,2,3)
        req.on('data', function (str) {
            sttt = sttt + str; // ne faire aucune opération avant de recevoir la réponse complète
        });
        req.on('end', function () {
            //console.log(sttt);
            var data = JSON.parse(sttt);
            qt = data.type;
            q = data.query;
            f = data.format;
            by = data.beginYear;
            ey = data.endYear;
            q = q.replace(/beginYear/, by);
            q = q.replace(/endYear/, ey);
            if (qt == 1) { // Query 1
                l = data.lab;
                q = q.replace(/param/, l);
            }
            else if (qt == 2) {
                l1 = data.lab1;
                l2 = data.lab2;
                q = q.replace(/lab1/, l1);
                q = q.replace(/lab2/, l2);
            }
            else {
                l = data.lab;
                c = data.country;
                q = q.replace(/lab/, l);
                q = q.replace(/countrye/, c.replace(/ /, "_"));
                q = q.replace(/countryf/, getFrenchName(c));
            }
            res.writeHeader(200, {'Content-Type': 'text/plain', 'Access-Control-Allow-Origin': '*'});
            var mg4 = require("./trans_mg4");
            var result = mg4.transform(q,qt);
            result = JSON.stringify(result);
            res.write(result, "utf-8"); // Renvoyer les données transformées au côté client
            res.end();
        });
    }
}).listen(port);

//console.log("Server started at port 8080. Now you can find this page at the website https://134.59.130.139:8080/index.html"); // VM
console.log("Server started at port 8080. Now you can find this page at the local address https://localhost:8080/index.html"); // local